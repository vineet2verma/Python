# simple_streamlit_app

![](Capture.PNG)
